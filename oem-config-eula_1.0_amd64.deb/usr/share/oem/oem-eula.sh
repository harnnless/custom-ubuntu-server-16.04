#!/bin/sh

set -e

. /usr/share/debconf/confmodule

LICENSE="$(cat /usr/share/oem/enterprise_eula.txt)"

# Create the template file
cat > /tmp/oem.template << EOF
Template: oem/title
Type: text
Description: OEM EULA confirm

Template: oem/present-eula
Type: note
Description: END-USER LICENSE AGREEMENT
 $LICENSE

Template: oem/accepted-eula
Type: boolean
Default: false
Description: Do you accept the EULA license terms?
 In order to install this package, you must accept the license terms, the 
 "OEM EULA". Not accepting will cancel the 
 installation.

Template: oem/error-eula
Type: error
Description: Declined "OEM EULA"
 If you do not agree to the "OEM EULA" license
 terms you cannot install this software.
 .
 The installation of this package will be canceled.
EOF

# Load your template
db_x_loadtemplatefile /tmp/oem.template oem

# Set title for your custom dialog box
db_settitle oem/title

# facilitate backup capability per debconf-devel(7)
STATE=1
while true; do
    case "$STATE" in
    0)  # ensure going back from license presentment is harmless
        STATE=1
        continue
        ;;
    1)  # present license
        db_fset oem/present-eula seen false
        if ! db_input critical oem/present-eula ; then
            exit 0
        fi
        db_fset oem/accepted-eula seen false
        if ! db_input critical oem/accepted-eula ; then
            exit 0
        fi
        ;;
    2)  # determine users' choice
        db_get oem/accepted-eula
        if [ "$RET" = "true" ]; then
            exit 0
        fi
        # error on decline license (give user chance to back up)
        db_input critical oem/error-eula
        ;;
    3)  # user has confirmed declining license
        echo "user did not accept the eula license" >&2
        shutdown -r now
        ;;
    *)  # unknown state
        echo "eula license state unknown: $STATE" >&2
        exit 2
        ;;
    esac
    if db_go; then
        STATE=$(($STATE + 1))
    else
        STATE=$(($STATE - 1))
    fi
done

